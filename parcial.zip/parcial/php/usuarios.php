<?php
include 'ob_user.php';
$users[] = new User('will',315563);
$users[] = new User('luci',300300);

